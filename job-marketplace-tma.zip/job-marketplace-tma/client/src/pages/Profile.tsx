import { Copy, Share2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { useState } from "react";

/**
 * Profile Screen - User Profile & Project Management
 * Design: Glassmorphism with tabs and project cards
 */

type TabType = "active" | "pending" | "done";

interface Project {
  id: number;
  icon: string;
  title: string;
  status: string;
  progress: number;
}

export default function Profile() {
  const [activeTab, setActiveTab] = useState<TabType>("active");
  const [showForm, setShowForm] = useState(false);
  const [copied, setCopied] = useState(false);

  const projects: Record<TabType, Project[]> = {
    active: [
      {
        id: 1,
        icon: "🌐",
        title: "Website Redesign",
        status: "In Progress",
        progress: 65,
      },
      {
        id: 2,
        icon: "📱",
        title: "Mobile App",
        status: "In Progress",
        progress: 40,
      },
    ],
    pending: [
      {
        id: 3,
        icon: "🎨",
        title: "UI Design System",
        status: "Pending",
        progress: 0,
      },
    ],
    done: [
      {
        id: 4,
        icon: "🤖",
        title: "Telegram Bot",
        status: "Completed",
        progress: 100,
      },
      {
        id: 5,
        icon: "🔐",
        title: "Smart Contract",
        status: "Completed",
        progress: 100,
      },
    ],
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText("0x7723c67d13c3733...");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F0F23] via-[#1A0F3F] to-[#0F0F23] text-white pb-24">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <img
          src="/images/pattern-accent.png"
          alt="pattern"
          className="w-full h-full object-cover"
        />
      </div>

      {/* User Header */}
      <div className="glass-hover backdrop-blur-md border-b border-cyan-500/20 relative z-10">
        <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center text-3xl">
              👨‍💻
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold">@alex_dev</h1>
              <p className="text-sm text-gray-400">⭐ 4.8 Rating</p>
            </div>
          </div>

          {/* Wallet Address */}
          <div className="glass p-3 flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 mb-1">Wallet Address</p>
              <p className="font-mono text-sm">0x7723c67d13c3733...</p>
            </div>
            <button
              onClick={handleCopyAddress}
              className="p-2 hover:bg-white/10 rounded-lg transition"
            >
              <Copy size={18} className={copied ? "text-green-400" : "text-cyan-400"} />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky top-16 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
        <div className="max-w-2xl mx-auto px-4 flex gap-2 overflow-x-auto">
          {(["active", "pending", "done"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-semibold text-sm whitespace-nowrap transition-all border-b-2 ${
                activeTab === tab
                  ? "border-cyan-400 text-cyan-400"
                  : "border-transparent text-gray-400 hover:text-cyan-300"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Projects List */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-3 relative z-10">
        {projects[activeTab].map((project, index) => (
          <div
            key={project.id}
            className="glass-hover p-4 space-y-3 cursor-pointer group animate-slide-up"
            style={{ animationDelay: `${index * 0.1}s` }}
            onClick={() => setShowForm(true)}
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl">{project.icon}</span>
              <div className="flex-1">
                <h3 className="font-semibold group-hover:text-cyan-400 transition">
                  {project.title}
                </h3>
                <p className="text-xs text-gray-400 mt-1">{project.status}</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-gray-400">
                <span>Progress</span>
                <span>{project.progress}%</span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-500"
                  style={{ width: `${project.progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}

        {projects[activeTab].length === 0 && (
          <div className="text-center py-12 space-y-3">
            <p className="text-gray-400">No projects yet</p>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold"
            >
              <Plus size={16} className="mr-2" />
              Create Project
            </Button>
          </div>
        )}
      </div>

      {/* Referral Section */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-3 relative z-10">
        <div className="glass-hover p-4 space-y-3 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <h3 className="font-semibold">Referral Program</h3>
          <p className="text-sm text-gray-400">
            Invite friends and earn 10% commission on their earnings!
          </p>
          <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold">
            <Share2 size={16} className="mr-2" />
            Invite Friends
          </Button>
        </div>
      </div>

      {/* Project Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end">
          <div className="w-full glass-hover border-t border-cyan-500/20 rounded-t-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Project Details</h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* User Info */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-300">Full Name</label>
                <input
                  type="text"
                  defaultValue="Alex Developer"
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-300">
                  Telegram Username
                </label>
                <input
                  type="text"
                  defaultValue="@alex_dev"
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              {/* Project Info */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-300">
                  Project Title
                </label>
                <input
                  type="text"
                  placeholder="e.g., Website Redesign"
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-300">
                  Project Description
                </label>
                <textarea
                  placeholder="Describe your project..."
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 resize-none"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-300">
                  Agreed Amount (CHIP)
                </label>
                <input
                  type="number"
                  placeholder="0"
                  className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => setShowForm(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button className="flex-1 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold">
                  Submit
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="profile" />
    </div>
  );
}
