import { Bell, TrendingUp, Crown, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { useState } from "react";

/**
 * Home Screen - Dashboard Overview
 * Design: Glassmorphism with dark gradient background
 * Features: Wallet snapshot, trending jobs, hall of fame
 */

export default function Home() {
  const [unreadNotifications] = useState(true);

  const trendingJobs = [
    {
      id: 1,
      icon: "📄",
      title: "Fix Smart Contract",
      reward: "500 CHIP",
      rating: "4.9",
    },
    {
      id: 2,
      icon: "🤖",
      title: "Build Telegram Bot",
      reward: "1000 CHIP",
      rating: "4.8",
    },
    {
      id: 3,
      icon: "🎨",
      title: "UI Design",
      reward: "750 CHIP",
      rating: "5.0",
    },
  ];

  const hallOfFame = [
    { id: 1, name: "Alex Dev", avatar: "👨‍💻", isTop: true },
    { id: 2, name: "Sarah Code", avatar: "👩‍💻", isTop: false },
    { id: 3, name: "Mike Build", avatar: "👨‍🔧", isTop: false },
    { id: 4, name: "Lisa Design", avatar: "👩‍🎨", isTop: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F0F23] via-[#1A0F3F] to-[#0F0F23] text-white pb-24">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <img
          src="/images/pattern-accent.png"
          alt="pattern"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Header */}
      <div className="sticky top-0 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
        <div className="max-w-2xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold gradient-text">Welcome, Alex</h1>
            <p className="text-sm text-gray-400">@alex_dev</p>
          </div>
          <button className="relative p-2 glass-hover rounded-full">
            <Bell size={20} />
            {unreadNotifications && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
            )}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6 relative z-10">
        {/* Hero Banner */}
        <div className="glass-hover p-6 space-y-3 animate-slide-up">
          <div className="flex items-center gap-3">
            <div className="text-3xl">📈</div>
            <div>
              <h2 className="text-lg font-bold">TON Breaks Record!</h2>
              <p className="text-sm text-gray-400">
                New highs for TON & CHIP tokens
              </p>
            </div>
          </div>
          <div className="h-1 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"></div>
        </div>

        {/* Wallet Section */}
        <div className="glass-hover p-6 space-y-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h3 className="text-lg font-semibold">Wallet Snapshot</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-cyan-500/20 to-cyan-500/5 rounded-lg p-4 border border-cyan-500/30">
              <p className="text-sm text-gray-400 mb-1">TON Balance</p>
              <p className="text-2xl font-bold">12.5 TON</p>
            </div>
            <div className="bg-gradient-to-br from-purple-500/20 to-purple-500/5 rounded-lg p-4 border border-purple-500/30">
              <p className="text-sm text-gray-400 mb-1">CHIP Balance</p>
              <p className="text-2xl font-bold">5,000 CHIP</p>
            </div>
          </div>
          <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold">
            Buy CHIP
          </Button>
        </div>

        {/* Trending Jobs */}
        <div className="space-y-3 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <h3 className="text-lg font-semibold px-2">Trending Jobs</h3>
          <div className="space-y-2">
            {trendingJobs.map((job) => (
              <div
                key={job.id}
                className="glass-hover p-4 flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3 flex-1">
                  <span className="text-2xl">{job.icon}</span>
                  <div className="flex-1">
                    <p className="font-semibold group-hover:text-cyan-400 transition">
                      {job.title}
                    </p>
                    <p className="text-sm text-gray-400">⭐ {job.rating}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-cyan-400">{job.reward}</p>
                  <ChevronRight
                    size={16}
                    className="text-gray-400 group-hover:text-cyan-400 transition"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hall of Fame */}
        <div className="space-y-3 animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <h3 className="text-lg font-semibold px-2">Hall of Fame</h3>
          <div className="glass-hover p-4 flex gap-3 overflow-x-auto pb-2">
            {hallOfFame.map((user) => (
              <div
                key={user.id}
                className="flex flex-col items-center gap-2 min-w-fit group cursor-pointer"
              >
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center text-lg group-hover:scale-110 transition">
                    {user.avatar}
                  </div>
                  {user.isTop && (
                    <Crown
                      size={16}
                      className="absolute -top-1 -right-1 text-yellow-400"
                    />
                  )}
                </div>
                <p className="text-xs text-center text-gray-400 group-hover:text-cyan-400 transition">
                  {user.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="home" />
    </div>
  );
}
