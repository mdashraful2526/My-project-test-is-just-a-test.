import { ArrowDownUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { useState, useEffect } from "react";

/**
 * Trade Screen - Token Swap Interface
 * Design: Glassmorphism with swap form and recent traders
 */

export default function Trade() {
  const [payAmount, setPayAmount] = useState("10");
  const [payCurrency, setPayCurrency] = useState("TON");
  const [receiveAmount, setReceiveAmount] = useState("5000");
  const [swapped, setSwapped] = useState(false);

  // Calculate exchange rate
  useEffect(() => {
    const amount = parseFloat(payAmount) || 0;
    if (payCurrency === "TON") {
      setReceiveAmount((amount * 500).toFixed(0));
    } else {
      setReceiveAmount((amount / 500).toFixed(2));
    }
  }, [payAmount, payCurrency]);

  const handleSwap = () => {
    setSwapped(true);
    setTimeout(() => setSwapped(false), 2000);
  };

  const handleToggleCurrency = () => {
    setPayCurrency(payCurrency === "TON" ? "CHIP" : "TON");
    setPayAmount("");
  };

  const recentTraders = [
    { id: 1, avatar: "👨‍💻" },
    { id: 2, avatar: "👩‍💻" },
    { id: 3, avatar: "👨‍🔧" },
    { id: 4, avatar: "👩‍🎨" },
    { id: 5, avatar: "👨‍🚀" },
    { id: 6, avatar: "👩‍🔬" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F0F23] via-[#1A0F3F] to-[#0F0F23] text-white pb-24">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <img
          src="/images/pattern-accent.png"
          alt="pattern"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Header */}
      <div className="sticky top-0 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold gradient-text">Trade</h1>
          <p className="text-sm text-gray-400">Swap tokens instantly</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6 relative z-10">
        {/* Swap Form */}
        <div className="glass-hover p-6 space-y-6 animate-slide-up">
          {/* You Pay Section */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-gray-300">You Pay</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="0"
                className="flex-1 bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:bg-white/10 transition text-lg font-semibold"
              />
              <select
                value={payCurrency}
                onChange={(e) => {
                  setPayCurrency(e.target.value);
                  setPayAmount("");
                }}
                className="bg-white/5 border border-cyan-500/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyan-500/50 focus:bg-white/10 transition font-semibold"
              >
                <option>TON</option>
                <option>CHIP</option>
              </select>
            </div>
          </div>

          {/* Swap Toggle */}
          <div className="flex justify-center">
            <button
              onClick={handleToggleCurrency}
              className="p-3 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-500/30 rounded-full transition"
            >
              <ArrowDownUp size={20} className="text-cyan-400" />
            </button>
          </div>

          {/* You Receive Section */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-gray-300">You Receive</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={receiveAmount}
                readOnly
                placeholder="0"
                className="flex-1 bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none text-lg font-semibold opacity-75"
              />
              <div className="bg-white/5 border border-cyan-500/20 rounded-lg px-4 py-3 text-white font-semibold flex items-center">
                {payCurrency === "TON" ? "CHIP" : "TON"}
              </div>
            </div>
          </div>

          {/* Exchange Rate */}
          <div className="text-center text-sm text-gray-400">
            {payCurrency === "TON"
              ? "1 TON ≈ 500 CHIP"
              : "1 CHIP ≈ 0.002 TON"}
          </div>

          {/* Swap Button */}
          {swapped ? (
            <div className="text-center py-4 space-y-2">
              <div className="text-3xl">✅</div>
              <p className="text-lg font-semibold text-cyan-400">Swap Successful!</p>
            </div>
          ) : (
            <Button
              onClick={handleSwap}
              disabled={!payAmount || parseFloat(payAmount) <= 0}
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold py-6 text-lg disabled:opacity-50"
            >
              Swap via STON.fi
            </Button>
          )}
        </div>

        {/* Recent Traders */}
        <div className="space-y-3 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h3 className="text-lg font-semibold px-2">Recent Traders</h3>
          <div className="glass-hover p-4 flex gap-3 overflow-x-auto pb-2">
            {recentTraders.map((trader) => (
              <div
                key={trader.id}
                className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center text-lg flex-shrink-0 cursor-pointer hover:scale-110 transition"
              >
                {trader.avatar}
              </div>
            ))}
          </div>
        </div>

        {/* Info Box */}
        <div className="glass-hover p-4 space-y-2 text-sm animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <p className="text-gray-400">
            💡 <span className="text-cyan-400">Tip:</span> Rates are updated in real-time. Swap now to get the best rates!
          </p>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="trade" />
    </div>
  );
}
