import { X, Send, Search, Filter, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { useState, useMemo } from "react";

/**
 * Market Screen - Job Listings & Proposals with Search & Filtering
 * Design: Glassmorphism with advanced search and filter capabilities
 */

interface Job {
  id: number;
  icon: string;
  title: string;
  description: string;
  reward: string;
  rewardAmount: number;
  rating: string;
  category: string;
  skills: string[];
  budget: "low" | "medium" | "high";
}

interface FilterState {
  searchQuery: string;
  category: string;
  budget: string;
  skills: string[];
}

export default function Market() {
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [coverLetter, setCoverLetter] = useState("");
  const [bidAmount, setBidAmount] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: "",
    category: "",
    budget: "",
    skills: [],
  });

  // Extended job data with categories and skills
  const jobs: Job[] = [
    {
      id: 1,
      icon: "🤖",
      title: "Build a Telegram Bot for Pizza Shop",
      description: "Build a Telegram Bot for Pizza Shop, order management etc.",
      reward: "500 CHIP",
      rewardAmount: 500,
      rating: "4.9",
      category: "Telegram Bot",
      skills: ["Telegram API", "Node.js", "Database"],
      budget: "medium",
    },
    {
      id: 2,
      icon: "🎨",
      title: "Website Redesign",
      description: "Complete redesign of e-commerce website with modern UI",
      reward: "1500 CHIP",
      rewardAmount: 1500,
      rating: "4.8",
      category: "Web Design",
      skills: ["React", "Tailwind CSS", "UI/UX"],
      budget: "high",
    },
    {
      id: 3,
      icon: "📱",
      title: "Mobile App Development",
      description: "Build a React Native mobile app for task management",
      reward: "2000 CHIP",
      rewardAmount: 2000,
      rating: "5.0",
      category: "Mobile Development",
      skills: ["React Native", "JavaScript", "Firebase"],
      budget: "high",
    },
    {
      id: 4,
      icon: "🔐",
      title: "Smart Contract Audit",
      description: "Security audit for Solidity smart contracts",
      reward: "1000 CHIP",
      rewardAmount: 1000,
      rating: "4.7",
      category: "Smart Contract",
      skills: ["Solidity", "Security", "Blockchain"],
      budget: "medium",
    },
    {
      id: 5,
      icon: "📝",
      title: "Technical Documentation",
      description: "Write comprehensive API documentation",
      reward: "300 CHIP",
      rewardAmount: 300,
      rating: "4.6",
      category: "Documentation",
      skills: ["Technical Writing", "API", "Markdown"],
      budget: "low",
    },
    {
      id: 6,
      icon: "🎬",
      title: "Video Tutorial Creation",
      description: "Create 5 tutorial videos for blockchain basics",
      reward: "800 CHIP",
      rewardAmount: 800,
      rating: "4.9",
      category: "Content Creation",
      skills: ["Video Editing", "Blockchain", "Communication"],
      budget: "medium",
    },
    {
      id: 7,
      icon: "🔍",
      title: "SEO Optimization",
      description: "Optimize website for search engines",
      reward: "600 CHIP",
      rewardAmount: 600,
      rating: "4.5",
      category: "Marketing",
      skills: ["SEO", "Analytics", "Content Strategy"],
      budget: "low",
    },
    {
      id: 8,
      icon: "⚙️",
      title: "Backend API Development",
      description: "Build REST API with Node.js and MongoDB",
      reward: "1200 CHIP",
      rewardAmount: 1200,
      rating: "4.8",
      category: "Backend Development",
      skills: ["Node.js", "MongoDB", "REST API"],
      budget: "high",
    },
  ];

  // Get unique categories and skills
  const categories = Array.from(new Set(jobs.map((job) => job.category)));
  const allSkills = Array.from(new Set(jobs.flatMap((job) => job.skills)));

  // Filter jobs based on search and filters
  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      // Search query filter
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesSearch =
          job.title.toLowerCase().includes(query) ||
          job.description.toLowerCase().includes(query);
        if (!matchesSearch) return false;
      }

      // Category filter
      if (filters.category && job.category !== filters.category) {
        return false;
      }

      // Budget filter
      if (filters.budget && job.budget !== filters.budget) {
        return false;
      }

      // Skills filter
      if (filters.skills.length > 0) {
        const hasRequiredSkills = filters.skills.some((skill) =>
          job.skills.includes(skill)
        );
        if (!hasRequiredSkills) return false;
      }

      return true;
    });
  }, [filters]);

  const handleSubmitProposal = () => {
    if (coverLetter.trim() && bidAmount.trim()) {
      setSubmitted(true);
      setTimeout(() => {
        setSelectedJob(null);
        setCoverLetter("");
        setBidAmount("");
        setSubmitted(false);
      }, 2000);
    }
  };

  const handleSkillToggle = (skill: string) => {
    setFilters((prev) => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter((s) => s !== skill)
        : [...prev.skills, skill],
    }));
  };

  const handleResetFilters = () => {
    setFilters({
      searchQuery: "",
      category: "",
      budget: "",
      skills: [],
    });
  };

  const activeFiltersCount =
    (filters.searchQuery ? 1 : 0) +
    (filters.category ? 1 : 0) +
    (filters.budget ? 1 : 0) +
    filters.skills.length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F0F23] via-[#1A0F3F] to-[#0F0F23] text-white pb-24">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <img
          src="/images/pattern-accent.png"
          alt="pattern"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Header */}
      <div className="sticky top-0 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold gradient-text">Market</h1>
          <p className="text-sm text-gray-400">
            {filteredJobs.length} job{filteredJobs.length !== 1 ? "s" : ""} found
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="sticky top-16 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
        <div className="max-w-2xl mx-auto px-4 py-3 space-y-3">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search
                size={18}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
              <input
                type="text"
                placeholder="Search jobs..."
                value={filters.searchQuery}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    searchQuery: e.target.value,
                  }))
                }
                className="w-full bg-white/5 border border-cyan-500/20 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:bg-white/10 transition text-sm"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="glass-hover p-2 rounded-lg relative"
            >
              <Filter size={18} />
              {activeFiltersCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-cyan-500 text-white text-xs rounded-full flex items-center justify-center">
                  {activeFiltersCount}
                </span>
              )}
            </button>
          </div>

          {/* Active Filters Display */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2">
              {filters.category && (
                <div className="bg-cyan-500/20 border border-cyan-500/40 rounded-full px-3 py-1 text-xs flex items-center gap-2">
                  {filters.category}
                  <button
                    onClick={() =>
                      setFilters((prev) => ({ ...prev, category: "" }))
                    }
                    className="hover:text-cyan-300"
                  >
                    ✕
                  </button>
                </div>
              )}
              {filters.budget && (
                <div className="bg-cyan-500/20 border border-cyan-500/40 rounded-full px-3 py-1 text-xs flex items-center gap-2">
                  {filters.budget.charAt(0).toUpperCase() +
                    filters.budget.slice(1)}{" "}
                  Budget
                  <button
                    onClick={() =>
                      setFilters((prev) => ({ ...prev, budget: "" }))
                    }
                    className="hover:text-cyan-300"
                  >
                    ✕
                  </button>
                </div>
              )}
              {filters.skills.map((skill) => (
                <div
                  key={skill}
                  className="bg-cyan-500/20 border border-cyan-500/40 rounded-full px-3 py-1 text-xs flex items-center gap-2"
                >
                  {skill}
                  <button
                    onClick={() => handleSkillToggle(skill)}
                    className="hover:text-cyan-300"
                  >
                    ✕
                  </button>
                </div>
              ))}
              <button
                onClick={handleResetFilters}
                className="text-xs text-gray-400 hover:text-cyan-400 transition"
              >
                Clear all
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="sticky top-32 z-40 glass-hover backdrop-blur-md border-b border-cyan-500/20">
          <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
            {/* Category Filter */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-300">
                Category
              </label>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() =>
                      setFilters((prev) => ({
                        ...prev,
                        category:
                          prev.category === category ? "" : category,
                      }))
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                      filters.category === category
                        ? "bg-cyan-500/30 border border-cyan-500/50 text-cyan-300"
                        : "bg-white/5 border border-cyan-500/20 text-gray-300 hover:bg-white/10"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Budget Filter */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-300">
                Budget
              </label>
              <div className="grid grid-cols-3 gap-2">
                {["low", "medium", "high"].map((budget) => (
                  <button
                    key={budget}
                    onClick={() =>
                      setFilters((prev) => ({
                        ...prev,
                        budget: prev.budget === budget ? "" : budget,
                      }))
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                      filters.budget === budget
                        ? "bg-cyan-500/30 border border-cyan-500/50 text-cyan-300"
                        : "bg-white/5 border border-cyan-500/20 text-gray-300 hover:bg-white/10"
                    }`}
                  >
                    {budget.charAt(0).toUpperCase() + budget.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Skills Filter */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-300">
                Required Skills
              </label>
              <div className="flex flex-wrap gap-2">
                {allSkills.map((skill) => (
                  <button
                    key={skill}
                    onClick={() => handleSkillToggle(skill)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition ${
                      filters.skills.includes(skill)
                        ? "bg-cyan-500/30 border border-cyan-500/50 text-cyan-300"
                        : "bg-white/5 border border-cyan-500/20 text-gray-300 hover:bg-white/10"
                    }`}
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Job List */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-3 relative z-10">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job, index) => (
            <div
              key={job.id}
              className="glass-hover p-4 cursor-pointer group animate-slide-up"
              style={{ animationDelay: `${index * 0.05}s` }}
              onClick={() => setSelectedJob(job)}
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl">{job.icon}</span>
                <div className="flex-1">
                  <h3 className="font-semibold group-hover:text-cyan-400 transition">
                    {job.title}
                  </h3>
                  <p className="text-sm text-gray-400 mt-1">
                    {job.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {job.skills.map((skill) => (
                      <span
                        key={skill}
                        className="text-xs bg-white/5 border border-cyan-500/20 rounded px-2 py-1 text-gray-300"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between items-center mt-3">
                    <span className="text-xs text-gray-500">⭐ {job.rating}</span>
                    <span className="text-cyan-400 font-bold">{job.reward}</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 space-y-3">
            <p className="text-gray-400 text-lg">No jobs found</p>
            <p className="text-gray-500 text-sm">
              Try adjusting your filters
            </p>
            <Button
              onClick={handleResetFilters}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Proposal Modal */}
      {selectedJob && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end">
          <div className="w-full glass-hover border-t border-cyan-500/20 rounded-t-2xl p-6 space-y-4 animate-slide-up max-h-[90vh] overflow-y-auto">
            {/* Close Button */}
            <button
              onClick={() => setSelectedJob(null)}
              className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition"
            >
              <X size={20} />
            </button>

            <h2 className="text-xl font-bold">Send Proposal</h2>

            {/* Job Summary */}
            <div className="bg-white/5 border border-cyan-500/20 rounded-lg p-3 space-y-2">
              <p className="text-sm text-gray-400">Job Details</p>
              <p className="font-semibold">{selectedJob.title}</p>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Budget:</span>
                <span className="text-cyan-400 font-bold">
                  {selectedJob.reward}
                </span>
              </div>
              <div className="flex flex-wrap gap-1">
                {selectedJob.skills.map((skill) => (
                  <span
                    key={skill}
                    className="text-xs bg-cyan-500/20 border border-cyan-500/30 rounded px-2 py-1"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {submitted ? (
              <div className="text-center py-8 space-y-2">
                <div className="text-4xl mb-4">✅</div>
                <p className="text-lg font-semibold text-cyan-400">
                  Proposal Sent Successfully!
                </p>
                <p className="text-sm text-gray-400">
                  The client will review your proposal soon.
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-300">
                    Cover Letter
                  </label>
                  <textarea
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    placeholder="Write your cover letter..."
                    className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:bg-white/10 transition resize-none"
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-300">
                    Bid Amount (CHIP)
                  </label>
                  <input
                    type="number"
                    value={bidAmount}
                    onChange={(e) => setBidAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full bg-white/5 border border-cyan-500/20 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:bg-white/10 transition"
                  />
                </div>

                <Button
                  onClick={handleSubmitProposal}
                  disabled={!coverLetter.trim() || !bidAmount.trim()}
                  className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold disabled:opacity-50"
                >
                  <Send size={16} className="mr-2" />
                  Submit Proposal
                </Button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <BottomNavigation activeTab="market" />
    </div>
  );
}
