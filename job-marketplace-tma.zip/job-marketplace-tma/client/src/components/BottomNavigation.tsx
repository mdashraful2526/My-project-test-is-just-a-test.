import { Home, ShoppingBag, ArrowLeftRight, User } from "lucide-react";
import { useLocation } from "wouter";

/**
 * Bottom Navigation Bar
 * Design: Fixed glassmorphism navigation with 4 tabs
 * Tabs: Home, Market, Trade, Profile
 */

interface BottomNavigationProps {
  activeTab?: "home" | "market" | "trade" | "profile";
}

export default function BottomNavigation({ activeTab = "home" }: BottomNavigationProps) {
  const [, navigate] = useLocation();

  const tabs = [
    { id: "home", label: "Home", icon: Home, path: "/" },
    { id: "market", label: "Market", icon: ShoppingBag, path: "/market" },
    { id: "trade", label: "Trade", icon: ArrowLeftRight, path: "/trade" },
    { id: "profile", label: "Profile", icon: User, path: "/profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 glass-hover backdrop-blur-md border-t border-cyan-500/20 z-50">
      <div className="max-w-2xl mx-auto px-4 py-3 flex justify-around items-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => navigate(tab.path)}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-300 ${
                isActive
                  ? "text-cyan-400 bg-cyan-500/10"
                  : "text-gray-400 hover:text-cyan-300"
              }`}
            >
              <Icon size={24} />
              <span className="text-xs font-semibold">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
