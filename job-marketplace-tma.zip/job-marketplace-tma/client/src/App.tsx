import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Market from "./pages/Market";
import Trade from "./pages/Trade";
import Profile from "./pages/Profile";

/**
 * Design Philosophy: Glassmorphism + Dark Crypto
 * - Dark gradient background (#0F0F23 to #1A0F3F)
 * - Cyan-to-purple gradient accents (#00D4FF to #9D4EDD)
 * - Glassmorphism effects with backdrop blur
 * - Neon glow animations
 */

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/market"} component={Market} />
      <Route path={"/trade"} component={Trade} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
